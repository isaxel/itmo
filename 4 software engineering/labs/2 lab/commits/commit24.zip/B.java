public class B extends null {

    private double i = 100.500;

    private long k = 4321;

    public void bb() {
        System.out.println(getClass().getName());
    }

    public double ad() {
        return 9.11;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public byte oo() {
        return 1;
    }

    public int af() {
        return -1;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public Object pp() {
        return this;
    }

    public int cc() {
        return 42;
    }

    public double ee() {
        return 500.100;
    }
}
