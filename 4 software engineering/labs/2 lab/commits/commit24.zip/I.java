public class I extends null {

    private long h = 1234;

    private int e = 1;

    public int cc() {
        return 13;
    }

    public void aa() {
        return;
    }

    public long dd() {
        return 100500;
    }

    public byte oo() {
        return 1;
    }

    public Object gg() {
        return new java.util.Random();
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public int af() {
        return -1;
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public double ad() {
        return 11.09;
    }

    public float ff() {
        return 0;
    }
}
