public class H extends null {

    long ac();

    java.util.Set<Integer> ll();

    public void bb() {
        System.out.println(getClass().getName());
    }

    public byte oo() {
        return 1;
    }

    public void aa() {
        System.out.println("void aa");
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }
}
