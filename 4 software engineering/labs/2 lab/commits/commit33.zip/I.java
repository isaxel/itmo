public class I extends null {

    private long h = 1234;

    private int e = 1;

    public int cc() {
        return 13;
    }

    public void aa() {
        return;
    }

    public long dd() {
        return 100500;
    }

    public byte oo() {
        return 2;
    }

    public Object gg() {
        return new java.util.Random();
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public float ff() {
        return 0;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public int af() {
        return -1;
    }

    public double ad() {
        return 11.09;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public Object pp() {
        return this;
    }
}
