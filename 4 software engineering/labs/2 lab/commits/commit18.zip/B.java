public class B extends null {

    private double i = 100.500;

    private long k = 4321;

    public void bb() {
        System.out.println(getClass().getName());
    }

    public double ad() {
        return 9.11;
    }

    public byte oo() {
        return 1;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public int af() {
        return -1;
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }
}
