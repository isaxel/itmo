public class H extends null {

    long ac();

    java.util.Set<Integer> ll();

    public void bb() {
        System.out.println(getClass().getName());
    }

    public byte oo() {
        return 3;
    }

    public Object rr() {
        return null;
    }

    public int cc() {
        return 42;
    }
}
