public class J extends B {

    private double e = 100.500;

    private int a = 42;

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public void ab() {
        return;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.LinkedList<Integer>;
    }

    public long ac() {
        return 333;
    }

    public int ae() {
        return java.lang.Math.abs(-7);
    }

    public int cc() {
        return 13;
    }

    public double ee() {
        return 500.100;
    }

    public Object gg() {
        return new java.util.Random();
    }
}
