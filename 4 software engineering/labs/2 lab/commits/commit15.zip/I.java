public class I extends null {

    private long h = 1234;

    private int e = 1;

    public int cc() {
        return 13;
    }

    public void aa() {
        return;
    }

    public long dd() {
        return 100500;
    }

    public byte oo() {
        return 1;
    }

    public Object gg() {
        return new java.util.Random();
    }
}
