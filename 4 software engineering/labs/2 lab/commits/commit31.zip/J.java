public class J extends B {

    private double e = 100.500;

    private int a = 42;

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public void ab() {
        return;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public long ac() {
        return 333;
    }

    public int ae() {
        return java.lang.Math.abs(-7);
    }

    public int[] ii() {
        return new int[]{4, 3, 2, 1};
    }

    public String kk() {
        return "Yes";
    }
}
