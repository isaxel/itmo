public class B {

    private double i = 100.500;

    private long k = 4321;

    public void bb() {
        System.out.println(getClass().getName());
    }

    public double ad() {
        return 9.11;
    }
}
