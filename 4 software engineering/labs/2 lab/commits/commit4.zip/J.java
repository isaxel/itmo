public class J extends B {

    private double e = 100.500;

    private int a = 42;

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public void ab() {
        return;
    }
}
