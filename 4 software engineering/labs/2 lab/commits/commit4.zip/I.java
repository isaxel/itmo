public class I {

    private long h = 1234;

    private int e = 1;

    public int cc() {
        return 13;
    }

    public void aa() {
        return;
    }
}
